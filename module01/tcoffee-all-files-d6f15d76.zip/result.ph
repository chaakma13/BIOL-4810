(((Ecoli_lacZ:0.02000,Kpneumoniae_lacZ:0.02000):0.24500,Bovatus_lacZ:0.22500):0.00000,Bintestinihominis:0.23500);
