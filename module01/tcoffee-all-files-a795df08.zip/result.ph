(((Ecoli_lacZ:0.02000,Kpneumoniae_lacZ:0.02000):0.30500,Bovatus_lacZ:0.32500):0.00000,Bintestinihominis:0.33500);
